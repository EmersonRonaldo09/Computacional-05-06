# Computational-Mathematics-SouthColombian-university-2022-1
This space has codes, scripts, and some stuff for teaching an learning
